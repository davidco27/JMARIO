package proyecto.juego.dominio;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.World;
import proyecto.juego.ui.PantallaJuego;

public class Goomba extends Villano {

    private Animaciones animaciones;
    public Goomba(PantallaJuego pantalla,World mundo, float x, float y,String id){
        super(mundo, x, y,id);
        animaciones=new Animaciones(pantalla);

    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        if(isVivo()){
            setPosition((getBody().getPosition().x - 0.36f) * 90, (getBody().getPosition().y - 0.42f) * 90);
            animaciones.animacionGoombaCorriendo(batch, this);}
    }
    @Override
    public void act(float delta) {
        if(isVivo())
            super.act(delta);
        else
            detach();
    }

}
