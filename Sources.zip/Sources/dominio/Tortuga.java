package proyecto.juego.dominio;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.World;
import proyecto.juego.ui.PantallaJuego;

public class Tortuga extends Villano {
   private Animaciones animaciones;
   private TextureRegion caparazonTortuga;
   public Tortuga(PantallaJuego pantalla, World mundo, float x, float y,String id){
      super(mundo, x, y,id);
       animaciones=new Animaciones(pantalla);
      caparazonTortuga = new TextureRegion(pantalla.getAtlas().findRegion("turtle"), 64, 0, 16, 24);
   }
    @Override
    public void draw(Batch batch, float parentAlpha) {
        if(isVivo()){
            setPosition((getBody().getPosition().x - 0.36f) * 90, (getBody().getPosition().y - 0.41f) * 90);
            animaciones.animacionTortugaCorriendo(batch, this);
        }
        else if (isCaparazon()){
            setPosition((getBody().getPosition().x - 0.36f) * 90, (getBody().getPosition().y - 0.41f) * 90);
            batch.draw(caparazonTortuga, getX(), getY(), getWidth(), getHeight());}

    }

    @Override
    public void act(float delta) {
       if(isVivo())
        super.act(delta);
       else if (!isCaparazon())
           this.detach();
    }

}
