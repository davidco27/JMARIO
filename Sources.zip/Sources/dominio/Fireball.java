package proyecto.juego.dominio;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.utils.Array;
import proyecto.juego.ui.PantallaJuego;

public class Fireball extends Actor {
    private String id;
    private boolean visible=true;
    private World mundo;
    private Fixture fixture;
    private Body body;
    private boolean der;
    private Animaciones animaciones;
    public Fireball(PantallaJuego pantalla,World mundo, float x, float y, boolean der,String id) {
        this.mundo=mundo;
        this.der=der;
        this.id=id;
        animaciones=new Animaciones(pantalla);
        BodyDef def = new BodyDef();
        if(der)
           def.position.set(x+0.35f,y+0.35f);
        else
            def.position.set(x-0.35f,y+0.35f);
        def.type = BodyDef.BodyType.KinematicBody;
        body = mundo.createBody(def);
        PolygonShape box = new PolygonShape();
        box.setAsBox(0.15f, 0.15f);
        fixture = body.createFixture(box, 3);
        fixture.setUserData(id);
        box.dispose();
        setSize(30,30);
        setPosition(x*90,y*90);
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        if(visible) {
            setPosition((body.getPosition().x - 0.3f) * 90, (body.getPosition().y - 0.3f) * 90);
            animaciones.animacionFireball(batch,this);
        }
    }
    @Override
    public void act(float delta) {
        if (!visible)
            detach();
        else{
        if(der)
            body.setLinearVelocity(new Vector2(2.5f, 0));
        else
            body.setLinearVelocity(new Vector2(-2.5f, 0));}
    }
    public boolean isVisible() {
        return visible;
    }

    public boolean isDer() {
        return der;
    }

    public String getId() {
        return id;
    }

    public void detach(){
        Array<Body> bodys=new Array<Body>();
        Array<Fixture> fixtures= body.getFixtureList();
        mundo.getBodies(bodys);
        if(bodys.contains(body,true) && fixtures.contains(fixture,true)){
            body.destroyFixture(fixture);
            mundo.destroyBody(body);
        }
        this.remove();
    }
    public void setVisible(boolean visible) {
        this.visible = visible;
    }
}
