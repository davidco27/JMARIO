package proyecto.juego.dominio;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.scenes.scene2d.Actor;
import proyecto.juego.ui.Juego;

public class Bandera extends Actor {
    private Texture bandera;
    public Bandera(float x, float y){
        bandera= Juego.getAdministrador().get("imagenes/bandera.png");
        setSize(90, 540);
        setPosition(x * 90, y * 90);

    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
         batch.draw(bandera,getX(), getY(), getWidth(), getHeight());
    }
}
