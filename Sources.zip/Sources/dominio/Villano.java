package proyecto.juego.dominio;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.utils.Array;

import proyecto.juego.ui.PantallaJuego;

public class Villano extends Actor {
    private boolean vivo=true;
    private  World mundo;
    private  Body body;
    private Jugador player;
    private boolean derecha=true;
    private boolean saltando;
    private String id;
    private boolean caparazon;
    private String idsup;
    private  Fixture fixture;
    private  Fixture fixtureSup;
    private boolean pisada;
    public Villano(World mundo, float x, float y,String id) {
        this.mundo = mundo;
        this.id=id;
        idsup=id+"s";
        BodyDef def = new BodyDef();
        def.position.set(x, y + 0.4f);
        def.type = BodyDef.BodyType.DynamicBody;
        body = this.mundo.createBody(def);
        PolygonShape box = new PolygonShape();
        box.setAsBox(0.2f,0.2f);
        fixture = body.createFixture(box, 1);
        fixture.setUserData(id);
        PolygonShape sup = new PolygonShape();
        Vector2[] vertice = new Vector2[4];
        vertice[0] = new Vector2(-0.16f, 0.20f);
        vertice[1] = new Vector2(0.16f, 0.20f);
        vertice[2] = new Vector2(-0.16f, 0.25f);
        vertice[3] = new Vector2(0.16f, 0.25f);
        sup.set(vertice);
        fixtureSup=body.createFixture(sup, 1);
        fixtureSup.setUserData(idsup);
        box.dispose();
        sup.dispose();
        setPosition(x *90, y * 90);
        setSize(36, 36);
    }

    public String getId() {
        return id;
    }

    public String getIdsup() {
        return idsup;
    }

    public void setSaltando(boolean saltando) {
        this.saltando = saltando;
    }

    @Override
    public void act(float delta) {
            float angle =body.getAngle();
            if(angle<(Math.PI) && angle>0.5){
                body.setTransform(body.getWorldCenter(), (float) (-(Math.PI)/2));}
            if(angle>(Math.PI))
                body.setTransform(body.getWorldCenter(), (float) ((Math.PI)/2));
                if(!saltando){
            player=PantallaJuego.getJugador();
            double dist =Math.sqrt(Math.pow(player.getX()-getX(),2)+ Math.pow(player.getY()-getY(),2));
            if(dist<300){
                if(player.getX()<getX()) {
                    derecha=false;
                    body.setLinearVelocity(-0.8f, 0);
                }
                else {
                    derecha=true;
                    body.setLinearVelocity(0.8f, 0);
                }
        }

    }}

    public boolean isDerecha() {
        return derecha;
    }

    public Body getBody() {
        return body;
    }

    public boolean isCaparazon() {
        return caparazon;
    }

    public boolean isPisada() {
        return pisada;
    }

    public void setPisada(boolean pisada) {
        this.pisada = pisada;
    }

    public void setCaparazon(boolean caparazon) {
        this.caparazon = caparazon;
    }

    public void detach() {
        Array<Body> bodys=new Array<Body>();
        Array<Fixture> fixtures= body.getFixtureList();
        mundo.getBodies(bodys);
        if(bodys.contains(body,true) && fixtures.contains(fixture,true) && fixtures.contains(fixtureSup,true)){
            body.destroyFixture(fixture);
            body.destroyFixture(fixtureSup);
            mundo.destroyBody(body);
        }
        this.remove();
    }
    public void setVivo(boolean vivo) {
        this.vivo = vivo;
    }



    public boolean isVivo() {
        return vivo;
    }

}

