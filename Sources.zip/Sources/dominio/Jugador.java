package proyecto.juego.dominio;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.utils.Array;
import proyecto.juego.ui.Juego;

import java.util.ArrayList;


public abstract class Jugador extends Actor {
        protected boolean vivo;
        private boolean bandera;
    protected Body body;
    private boolean derecha=true;
    protected enum Estados{
        PARADO,
        CORRIENDO,
        SALTANDO};
    protected Estados estadoActual;
        protected World mundo;
        private boolean saltando;
    protected Fixture fixture;
    private ArrayList<Fireball> fireballs=new ArrayList<>();
    private Sound sonidoSalto;
        public Jugador(World mundo) {
            this.vivo= true;
            this.mundo=mundo;
            saltando=false;
            sonidoSalto= Juego.getAdministrador().get("audio/jump.ogg");
            estadoActual=Estados.PARADO;

        }


    @Override
    public void act(float delta) {
         if (!vivo){
             detach();
         }
         else if(bandera){
             estadoActual=Estados.PARADO;
             body.setLinearVelocity( new Vector2(0, -0.5f));
         }
         else {
       if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)&& !saltando ){
           body.setLinearVelocity( new Vector2(2f, 0));
       estadoActual=Estados.CORRIENDO;
           derecha=true;}
       else if (Gdx.input.isKeyPressed(Input.Keys.LEFT)&& !saltando && getX()>-100){
           body.setLinearVelocity( new Vector2(-2f, 0));
           estadoActual=Estados.CORRIENDO;
          derecha=false;}
       else if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)&& !saltando){
           sonidoSalto.play();
           this.saltar();
           estadoActual=Estados.SALTANDO;
       }
       else if(body.getLinearVelocity().y>0.3)
                 estadoActual=Estados.SALTANDO;
       else
               estadoActual=Estados.PARADO;

       if (saltando){
           body.applyForceToCenter(0, -30 * 1.15f, true);
           if (Gdx.input.isKeyPressed(Input.Keys.RIGHT))
               body.applyLinearImpulse(new Vector2(0.25f,0),body.getWorldCenter(),true);
           else if (Gdx.input.isKeyPressed(Input.Keys.LEFT) && getX()>-100)
               body.applyLinearImpulse(new Vector2(-0.25f,0),body.getWorldCenter(),true);
       }}
         }
        public void detach(){
            Array<Body> bodys=new Array<Body>();
            Array<Fixture> fixtures= body.getFixtureList();
            mundo.getBodies(bodys);
            if(bodys.contains(body,true) && fixtures.contains(fixture,true)){
                body.destroyFixture(fixture);
               mundo.destroyBody(body);
            }
            this.remove();
        }
     public void setVivo(boolean vivo) {
    this.vivo = vivo;
        }

    public boolean isBandera() {
        return bandera;
    }

    public void setBandera(boolean bandera) {
        this.bandera = bandera;
    }

    public void setSaltando(boolean saltando) {
        this.saltando = saltando;
    }

    public Fixture getFixture() {
        return fixture;
    }

    public ArrayList<Fireball> getFireballs() {
        return fireballs;
    }

    public boolean isSaltando() {
        return saltando;
    }

    public boolean isDerecha() {
        return derecha;
    }

    public Body getBody() {
        return body;
    }

    public void saltar(){
            saltando=true;
            Vector2 position = body.getPosition();
            body.applyLinearImpulse(0,17, position.x, position.y, true);
        }

    }