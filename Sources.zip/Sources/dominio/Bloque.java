package proyecto.juego.dominio;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import proyecto.juego.ui.Juego;

public class Bloque extends Actor {
    private Texture bloque;
    private float x,y;
    public Bloque(float x, float y){
        this.x=x;
        this.y=y;
        bloque= Juego.getAdministrador().get("imagenes/bloque.png");
        setPosition(x*90,y*90);
        setSize(45, 45);
    }
    @Override
    public void draw(Batch batch, float parentAlpha) {
        // Render both textures.
        batch.draw(bloque, getX(), getY(), getWidth(), getHeight());
    }
}
