package proyecto.juego.dominio;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Array;
import proyecto.juego.ui.PantallaJuego;

public class Animaciones {
    private int cont;
    private TextureRegion marioParado;
    private TextureRegion marioSalta;
    Array<TextureRegion> marioCorre= new Array<>();
    Array<TextureRegion> fireball= new Array<>();
    private TextureRegion marioFuegoParado;
    private TextureRegion marioFuegoSalta;
    Array<TextureRegion> marioFuegoCorre= new Array<>();
    Array<TextureRegion> goombaCorre= new Array<>();
    Array<TextureRegion> tortugaCorre= new Array<>();
    public Animaciones(PantallaJuego pantalla){
        for(int i = 1; i < 4; i++)
            marioCorre.add(new TextureRegion(pantalla.getAtlas().findRegion("little_mario"), i * 16, 0, 16, 16));
        marioParado=  new TextureRegion(pantalla.getAtlas().findRegion("little_mario"), 0, 0, 16, 16);
        marioSalta = new TextureRegion(pantalla.getAtlas().findRegion("little_mario"), 80, 0, 16, 16);
        for(int i = 1; i < 4; i++)
            marioFuegoCorre.add(new TextureRegion(pantalla.getAtlas().findRegion("big_mario"), i * 16, 0, 16, 32));
        marioFuegoParado=  new TextureRegion(pantalla.getAtlas().findRegion("big_mario"), 0, 0, 16, 32);
        marioFuegoSalta = new TextureRegion(pantalla.getAtlas().findRegion("big_mario"), 80, 0, 16, 32);
        for(int i = 0; i < 2; i++)
        goombaCorre.add(new TextureRegion(pantalla.getAtlas().findRegion("goomba"), i*16, 0, 16, 16));
        for(int i = 0; i < 2; i++)
            tortugaCorre.add(new TextureRegion(pantalla.getAtlas().findRegion("turtle"), i * 16, 0, 16, 24));
        for(int i = 0; i < 4; i++){
            fireball.add(new TextureRegion(pantalla.getAtlas().findRegion("fireball"), i * 8, 0, 8, 8));
        }

    }
    public  void animacionJugadorCorriendo(Batch batch,Jugador player){
        TextureRegion frameCorre=marioCorre.get(cont/5);
        if(player.isDerecha()){
            if(frameCorre.isFlipX())
                frameCorre.flip(true, false);
            batch.draw(frameCorre,player.getX(),player.getY(), player.getWidth(), player.getHeight());}
        else {
            if(!frameCorre.isFlipX())
                frameCorre.flip(true, false);
            batch.draw(frameCorre, player.getX(), player.getY(), player.getWidth(), player.getHeight());
        }
        if(cont==14)
            cont =0;
        else
            cont++;
    }
    public  void animacionJugadorFuegoCorriendo(Batch batch,Jugador player){
        TextureRegion frameCorre=marioFuegoCorre.get(cont/5);
        if(player.isDerecha()){
            if(frameCorre.isFlipX())
                frameCorre.flip(true, false);
            batch.draw(frameCorre,player.getX(),player.getY(), player.getWidth(), player.getHeight());}
        else {
            if(!frameCorre.isFlipX())
                frameCorre.flip(true, false);
            batch.draw(frameCorre, player.getX(), player.getY(), player.getWidth(), player.getHeight());
        }
        if(cont==14)
            cont =0;
        else
            cont++;
    }
    public  void animacionGoombaCorriendo(Batch batch,Goomba player){
        batch.draw(goombaCorre.get(cont/10),player.getX(),player.getY(), player.getWidth(), player.getHeight());
        if(cont==19)
            cont =0;
        else
            cont++;
    }
    public  void animacionTortugaCorriendo(Batch batch,Tortuga player){
        TextureRegion frameCorre=tortugaCorre.get(cont/10);
        if(!player.isDerecha()){
            if(frameCorre.isFlipX())
                frameCorre.flip(true, false);
            batch.draw(frameCorre,player.getX(),player.getY(), player.getWidth(), player.getHeight());}
        else {
            if(!frameCorre.isFlipX())
                frameCorre.flip(true, false);
            batch.draw(frameCorre, player.getX(), player.getY(), player.getWidth(), player.getHeight());
        }
        if(cont==19)
            cont =0;
        else
            cont++;
    }
    public  void animacionJugadorNormal(Batch batch,Jugador player){
        if(player.isDerecha()){
            if(marioParado.isFlipX())
                marioParado.flip(true, false);
            batch.draw(marioParado,player.getX(),player.getY(), player.getWidth(), player.getHeight());}
        else {
            if(!marioParado.isFlipX())
            marioParado.flip(true, false);
            batch.draw(marioParado, player.getX(), player.getY(), player.getWidth(), player.getHeight());
        }
    }
    public  void animacionJugadorSaltando(Batch batch,Jugador player){
        if(player.isDerecha()){
            if(marioSalta.isFlipX())
                marioSalta.flip(true, false);
            batch.draw(marioSalta,player.getX(),player.getY(), player.getWidth(), player.getHeight());}
        else {
            if(!marioSalta.isFlipX())
                marioSalta.flip(true, false);
            batch.draw(marioSalta, player.getX(), player.getY(), player.getWidth(), player.getHeight());
        }
    }
    public  void animacionJugadorFuego(Batch batch,Jugador player){
        if(player.isDerecha()){
            if(marioFuegoParado.isFlipX())
                marioFuegoParado.flip(true, false);
            batch.draw(marioFuegoParado,player.getX(),player.getY(), player.getWidth(), player.getHeight());}
        else {
            if(!marioFuegoParado.isFlipX())
                marioFuegoParado.flip(true, false);
            batch.draw(marioFuegoParado, player.getX(), player.getY(), player.getWidth(), player.getHeight());
        }
    }
    public  void animacionJugadorFuegoSaltando(Batch batch,Jugador player){
        if(player.isDerecha()){
            if(marioFuegoSalta.isFlipX())
                marioFuegoSalta.flip(true, false);
            batch.draw(marioFuegoSalta,player.getX(),player.getY(), player.getWidth(), player.getHeight());}
        else {
            if(!marioFuegoSalta.isFlipX())
                marioFuegoSalta.flip(true, false);
            batch.draw(marioFuegoSalta, player.getX(), player.getY(), player.getWidth(), player.getHeight());
        }}
        public void animacionFireball(Batch batch,Fireball player){
            TextureRegion frameCorre=fireball.get(cont/5);
            if(player.isDer()){
                if(frameCorre.isFlipX())
                    frameCorre.flip(true, false);
                batch.draw(frameCorre,player.getX(),player.getY(), player.getWidth(), player.getHeight());}
            else {
                if(!frameCorre.isFlipX())
                    frameCorre.flip(true, false);
                batch.draw(frameCorre, player.getX(), player.getY(), player.getWidth(), player.getHeight());
            }
            if(cont==14)
                cont =0;
            else
                cont++;

        }
}
