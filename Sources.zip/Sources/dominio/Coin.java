package proyecto.juego.dominio;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import proyecto.juego.ui.Juego;
import proyecto.juego.ui.PantallaJuego;

public class Coin extends Actor {
    private Texture moneda;
    private boolean visible=true;
    private String id;
    public Coin(float x,float y,String id) {
        this.id=id;
        moneda = Juego.getAdministrador().get("imagenes/coin.png");
        setSize(20,20);
        setPosition(x*90,y*90);
    }
    public boolean comprobarColisiones(){
      Jugador player= PantallaJuego.getJugador();
        return player.getX()> getX()-20 && player.getY()  > getY()-20 &&
                player.getX() < getX()+20 && player.getY() <getY() +20;
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        if(visible) {
            batch.draw(moneda, getX()+30, getY()+30, getWidth(), getHeight());
        }
    }
    public boolean isVisible() {
        return visible;
    }
    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public String getId() {
        return id;
    }
}
