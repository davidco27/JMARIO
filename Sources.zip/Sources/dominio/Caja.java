package proyecto.juego.dominio;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.utils.Array;
import proyecto.juego.ui.Juego;
import proyecto.juego.ui.PantallaJuego;

public class Caja extends Actor {
    private World world;
    private Fixture fixture;
    private boolean visible=true;
    private Texture caja;
    private Texture estrella;
    private TextureRegion champinon;
    private PantallaJuego pantalla;
    private Body body;
    public enum Recompensas{
        SIN_ABRIR,
        CHAMPINON,
        ESTRELLA
    };
    private Recompensas sorpresa;
    private String id;
    public Caja(PantallaJuego pantalla,World world, float x, float y,String id) {
        this.world = world;
        this.pantalla=pantalla;
        caja = Juego.getAdministrador().get("imagenes/box.png");
        estrella= Juego.getAdministrador().get("imagenes/estrella.png");
        champinon=new TextureRegion(pantalla.getAtlas().findRegion("mushroom"), 0, 0, 16, 16);
        BodyDef def = new BodyDef();
        def.position.set(x+0.3f, y+0.4f);
        body = world.createBody(def);
        PolygonShape box = new PolygonShape();
        box.setAsBox(0.2f, 0.2f);
        fixture = body.createFixture(box, 1);
        fixture.setUserData(id);
        this.id=id;
        box.dispose();
        sorpresa=Recompensas.SIN_ABRIR;
        setSize(45,45);
        setPosition(x * 90, y * 90);
}

    @Override
    public void draw(Batch batch, float parentAlpha) {
        if(visible) {
            if (sorpresa == Recompensas.SIN_ABRIR)
                batch.draw(caja, getX(), getY(), getWidth(), getHeight());
            else if (sorpresa == Recompensas.CHAMPINON)
                batch.draw(champinon, getX(), getY() + 45, 40, 40);
            else if (sorpresa==Recompensas.ESTRELLA)
                batch.draw(estrella, getX(), getY() + 45, 40, 40);
        }
    }

    public String getId() {
        return id;
    }

    @Override
    public void act(float delta) {
        if(!visible)
            detach();
        else{
        Jugador player= PantallaJuego.getJugador();
        if ( player.getX()> getX()-30 && player.getY()  > getY()+15 && player.getX() < getX()+30 && player.getY() <getY() +60){
            if(sorpresa==Recompensas.CHAMPINON){
                visible=false;
            pantalla.cambiarFuego();}
           else if(sorpresa==Recompensas.ESTRELLA){
               visible=false;
               pantalla.cambiarEstrella();
            }
        }
    }}

    public void detach(){
        Array<Body> bodys=new Array<Body>();
        Array<Fixture> fixtures= body.getFixtureList();
        world.getBodies(bodys);
        if(bodys.contains(body,true) && fixtures.contains(fixture,true)){
            body.destroyFixture(fixture);
            world.destroyBody(body);
        }
        this.remove();
    }
    public void setSorpresa(Recompensas sorpresa) {
        this.sorpresa = sorpresa;
    }

    public Recompensas getSorpresa() {
        return sorpresa;
    }

    @Override
    public void setVisible(boolean visible) {
        this.visible = visible;
    }
}
