package proyecto.juego.dominio;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.scenes.scene2d.Actor;
import proyecto.juego.ui.Juego;

import java.util.ArrayList;

public class Plataforma extends Actor {
    private World world;
    private ArrayList<Bloque> bloques;
    private Fixture fixture;
    private Body body;
    public Plataforma(World world, float x, float y,float height,float width) {
        this.world = world;
        bloques=new ArrayList<>();
        BodyDef def = new BodyDef();
        def.position.set(x+width/2, y+((height+0.4f)/2));
        body = world.createBody(def);
        PolygonShape box = new PolygonShape();
        box.setAsBox(width / 2, height/2);
        fixture = body.createFixture(box, 1);
        fixture.setUserData("floor");
        box.dispose();
        for(float i=0;i<height;i+=0.5)
            for(float j=0;j<width;j+=0.5)
                bloques.add(new Bloque(x+j,y+i));
        setSize(width * 90, height*90);
        setPosition(x * 90, y * 90);
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        for(Bloque bloque : bloques)
           bloque.draw(batch, parentAlpha);
    }

    public void detach() {
        body.destroyFixture(fixture);
        world.destroyBody(body);
    }
}
