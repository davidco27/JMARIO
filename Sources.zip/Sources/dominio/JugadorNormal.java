package proyecto.juego.dominio;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import proyecto.juego.ui.PantallaJuego;

public class JugadorNormal extends Jugador {
   private Animaciones animaciones;
    public JugadorNormal(PantallaJuego pantalla,World mundo, Vector2 posicion){
        super(mundo);
        BodyDef def = new BodyDef();
        def.position.set(posicion);
        def.type = BodyDef.BodyType.DynamicBody;
        body = mundo.createBody(def);
        PolygonShape box = new PolygonShape();
        box.setAsBox(0.3f, 0.3f);
        fixture = body.createFixture(box, 3);
        fixture.setUserData("jugador");
        animaciones=new Animaciones(pantalla);
        box.dispose();
        setSize(60,60);
        setPosition(90,45);
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        if (vivo) {
            setPosition((body.getPosition().x - 0.4f) * 90, (body.getPosition().y - 0.54f) * 90);
            switch (estadoActual){
                case SALTANDO:
                animaciones.animacionJugadorSaltando(batch, this);
                break;
                case CORRIENDO:
                    animaciones.animacionJugadorCorriendo(batch, this);
                    break;
                case PARADO:
                animaciones.animacionJugadorNormal(batch, this);
                break;
        }
    }
}}
