package proyecto.juego.dominio;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import proyecto.juego.ui.Juego;
import proyecto.juego.ui.PantallaJuego;


public class JugadorFuego extends Jugador {
    private  PantallaJuego pantalla;
    private Sound fireball;
    private int contFireball;
    private Animaciones animaciones;
          public JugadorFuego(PantallaJuego pantalla,World mundo, Vector2 posicion){
             super(mundo);
             this.pantalla=pantalla;
             BodyDef def = new BodyDef();
             def.position.set(posicion);
             def.type = BodyDef.BodyType.DynamicBody;
             body = mundo.createBody(def);
             PolygonShape box = new PolygonShape();
             box.setAsBox(0.4f, 0.4f);
             fixture = body.createFixture(box, 1.6f);
             fixture.setUserData("jugador");
              animaciones=new Animaciones(pantalla);
             box.dispose();
             fireball= Juego.getAdministrador().get("audio/fireball.mp3");
             setSize(60,75);
     }

    @Override
    public void act(float delta) {
        super.act(delta);
        if (Gdx.input.isKeyJustPressed(Input.Keys.UP))
            lanzarFuego("f"+contFireball);
    }
    @Override
    public void draw(Batch batch, float parentAlpha) {
        if (vivo) {
            setPosition((body.getPosition().x - 0.4f) * 90, (body.getPosition().y - 0.65f) * 90);
            switch (estadoActual){
                case SALTANDO:
                    animaciones.animacionJugadorFuegoSaltando(batch, this);
                    break;
                case CORRIENDO:
                    animaciones.animacionJugadorFuegoCorriendo(batch, this);
                    break;
                case PARADO:
                    animaciones.animacionJugadorFuego(batch, this);
                    break;
            }
        }}
    public void lanzarFuego(String id){
        Fireball fball= new Fireball(pantalla,mundo,body.getPosition().x,body.getPosition().y-0.5f,isDerecha(),id);
             fireball.play();
              pantalla.getEscenario().addActor(fball);
              getFireballs().add(fball);
              contFireball++;
    }
}
