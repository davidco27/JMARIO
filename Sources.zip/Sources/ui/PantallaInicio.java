package proyecto.juego.ui;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class PantallaInicio extends Pantalla {

    private SpriteBatch batch;
    private Stage escenario;
    private TextButton btnPlay;
    private BitmapFont bm;
    private Texture fondo;
    public PantallaInicio(Juego game){
        super(game);
        escenario = new Stage(new ScreenViewport());
        Skin skin = new Skin(new FileHandle("skins/craftacular/skin/craftacular-ui.json"));
        fondo = Juego.getAdministrador().get("imagenes/fondoinicial.jpg");
        btnPlay = new TextButton("PLAY", skin);
        bm= new BitmapFont(new FileHandle("skins/craftacular/raw/font-title-export.fnt"));
        escenario.addActor(btnPlay);
        batch =new SpriteBatch();
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(escenario);
        btnPlay.setPosition(140, 210);
        btnPlay.addListener(new ClickListener(){
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new PantallaMenu(game));
            };
        });}

    @Override
    public void dispose() {
    super.dispose();
    escenario.clear();
        escenario.dispose();
    }

    @Override
    public void hide() {
        this.dispose();
    }

    @Override
    public void render(float delta) {
        super.render(delta);
        batch.begin();
        batch.draw(fondo,0,0,660,300);
        bm.draw(batch,"JMARIO",140,420);
        batch.end();
        escenario.act();
        escenario.draw();
    }
}