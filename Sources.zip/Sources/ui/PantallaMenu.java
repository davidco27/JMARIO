package proyecto.juego.ui;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class PantallaMenu extends  Pantalla {
    private Stage escenario;
    private TextButton btn1,btn2;
    private SpriteBatch batch;
    private Texture fondo;
    public PantallaMenu(Juego game){
        super(game);
    escenario = new Stage(new ScreenViewport());
    Skin skin = new Skin(new FileHandle("skins/craftacular/skin/craftacular-ui.json"));
    fondo = Juego.getAdministrador().get("imagenes/fondoinicial.jpg");
    btn1 = new TextButton("LEVEL 1", skin);
    btn2 = new TextButton("LEVEL 2", skin);
        escenario.addActor(btn1);
        escenario.addActor(btn2);
    batch =new SpriteBatch();
}

    @Override
    public void show() {
        Gdx.input.setInputProcessor(escenario);
        btn1.setPosition(140, 350);
        btn2.setPosition(140, 220);
        btn1.addListener(new ClickListener(){
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new PantallaJuego(game,1));
            };
        });
        btn2.addListener(new ClickListener(){
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new PantallaJuego(game,2));
            };
        });}

    @Override
    public void dispose() {
        super.dispose();
        escenario.clear();
        escenario.dispose();
    }

    @Override
    public void hide() {
        this.dispose();
    }

    @Override
    public void render(float delta) {
        super.render(delta);
        batch.begin();
        batch.draw(fondo,0,0,660,300);
        batch.end();
        escenario.act();
        escenario.draw();
    }
}
