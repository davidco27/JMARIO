package proyecto.juego.ui;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;


public abstract class Pantalla extends ScreenAdapter{
    protected Juego game;
     public Pantalla(Juego game){
         this.game=game;
     }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.62f, 0.66f, 1, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
    }
}
