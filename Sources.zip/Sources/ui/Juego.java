package proyecto.juego.ui;


import com.badlogic.gdx.Game;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;


public class Juego extends Game {
  private static AssetManager administrador;//para cargar texturas y sonidos

	@Override
	public void create() {
		administrador = new AssetManager();
		administrador.load("imagenes/fondoinicial.jpg", Texture.class);
		administrador.load("imagenes/Mario_and_Enemies.pack", TextureAtlas.class);
		administrador.load("imagenes/coin.png", Texture.class);
		administrador.load("imagenes/bloque.png",Texture.class);
		administrador.load("imagenes/bandera.png",Texture.class);
		administrador.load("imagenes/box.png", Texture.class);
		administrador.load("imagenes/gameover.png", Texture.class);
		administrador.load("imagenes/suelo.png", Texture.class);
		administrador.load("imagenes/estrella.png", Texture.class);
		administrador.load("audio/jump.ogg", Sound.class);
		administrador.load("audio/muerte.mp3", Sound.class);
		administrador.load("audio/final.mp3", Sound.class);
		administrador.load("audio/fireball.mp3", Sound.class);
		administrador.load("audio/powerUp.mp3", Sound.class);
		administrador.load("audio/moneda.mp3", Sound.class);
		administrador.load("audio/champinon.mp3", Sound.class);
		administrador.load("audio/marioDecrece.mp3", Sound.class);
		administrador.load("audio/cancion.ogg", Music.class);
		administrador.load("audio/cancionEstrella.mp3", Music.class);
		setScreen(new PantallaCarga(this));
	}
	public static AssetManager getAdministrador(){
		return administrador;
	}
}