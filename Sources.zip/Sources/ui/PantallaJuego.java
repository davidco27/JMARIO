package proyecto.juego.ui;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import proyecto.juego.dominio.*;
import proyecto.juego.io.IOElementos;


import java.util.ArrayList;


public class PantallaJuego extends Pantalla {
    private  Stage escenario;
    private boolean finalJuego;
    private int contadorMonedas;
    private  int puntosExtra;
    private World mundo;
    private boolean cambioNormal;
    private boolean estrella;
    private static Jugador jugador;
    private float tiempo;
    private final static float TIEMPO_ESTRELLA=10;
    private Camera camara;
   private ArrayList<Villano> villanos;//Arraylist de villanos
    private ArrayList<Plataforma> plataformas;//Arraylist de plataformas
    private ArrayList<Coin> monedas;
    private ArrayList<Caja> cajas;
    private Sound sonidoMoneda;
    private Sound sonidoChampinon;
    private Sound sonidoPowerUp;
    private Sound sonidoPowerDown;
    private Sound sonidoFinal;
    private boolean nivelCompletado;
    private  TextureAtlas atlas;
   private Music musicaFondo;
   private int enemigosAsesinados;
   private  int level;
    private Music musicaEstrella;
    private Vector3 posicion;//posicion de la camara

    public PantallaJuego(Juego game,int level){
        super(game);
        this.level=level;
        atlas=game.getAdministrador().get("imagenes/Mario_and_Enemies.pack");
        escenario = new Stage(new ScreenViewport());
        camara= escenario.getCamera();
        camara.viewportHeight=700;
        camara.viewportWidth=700;
        camara.update();
        posicion = new Vector3(camara.position);
        mundo = new World(new Vector2(0,-10f),true);
        mundo.setContactListener(new DetectorContactos());
        villanos = IOElementos.leerEnemigos(this,mundo,level);
        cajas = IOElementos.leerCajas(this,mundo,level);
        plataformas = IOElementos.leerPlataformas(mundo,level);
        monedas=IOElementos.leerMonedas(level);
        jugador = new JugadorNormal(this,mundo,new Vector2(1, 2));
        sonidoMoneda = Juego.getAdministrador().get("audio/moneda.mp3");
        sonidoChampinon = Juego.getAdministrador().get("audio/champinon.mp3");
        sonidoPowerUp = Juego.getAdministrador().get("audio/powerUp.mp3");
        sonidoPowerDown = Juego.getAdministrador().get("audio/marioDecrece.mp3");
        sonidoFinal = Juego.getAdministrador().get("audio/final.mp3");
        musicaFondo = Juego.getAdministrador().get("audio/cancion.ogg");
        musicaEstrella = Juego.getAdministrador().get("audio/cancionEstrella.mp3");
    }
    @Override
    public void show() {
        escenario.addActor(new Bandera(148,6));
        escenario.addActor(jugador);
        for(Villano  villano: villanos)
            escenario.addActor(villano);
        for(Coin moneda : monedas) {
            escenario.addActor(moneda);
        }
        for(Plataforma plataforma : plataformas)
            escenario.addActor(plataforma);
        for(Caja caja : cajas)
            escenario.addActor(caja);
        camara.position.set(posicion);
        camara.update();
        musicaFondo.setVolume(0.5f);
        musicaFondo.setLooping(true);
        musicaFondo.play();
    }


    @Override
    public void hide() {
        escenario.clear();
        jugador.detach();
        for(Villano  villano: villanos)
            villano.detach();
        for(Plataforma plataforma : plataformas)
            plataforma.detach();
        this.dispose();
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.4f, 0.5f, 0.8f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        escenario.act();
        mundo.step(delta, 6, 2);
        if(jugador.getY()<0)
            finalJuego = true;
        if(finalJuego){
            musicaEstrella.stop();
            musicaFondo.stop();
            game.setScreen(new PantallaGameOver(game,this));
        }
        if(nivelCompletado)
            game.setScreen(new PantallaFinal(game,this));
        if(cambioNormal)
            cambiarNormal();
        cogerMonedas();
        if(jugador.getX()>=148*90 && !jugador.isBandera())
         llegarBandera();
        camara.position.x =jugador.getX();
        camara.position.y =jugador.getY()+90;
        camara.update();
        if (estrella)
            if(tiempo<TIEMPO_ESTRELLA)
             tiempo+=delta;
            else
                acabarEstrella();
        escenario.draw();
    }

    /**
     * This method is executed when the screen can be safely disposed.
     * I use this method to dispose things that have to be manually disposed.
     */
    @Override
    public void dispose() {
        escenario.dispose();
        mundo.dispose();
    }

    public int getContadorMonedas() {
        return contadorMonedas;
    }

    public int getLevel() {
        return level;
    }

    public int getEnemigosAsesinados() {
        return enemigosAsesinados;
    }

    public  Stage getEscenario() {
        return escenario;
    }

    public static Jugador getJugador() {
        return jugador;
    }

    public  TextureAtlas getAtlas() {
        return atlas;
    }
public  void cogerMonedas(){
    for(int i=0;i<monedas.size();i++){
        Coin moneda=monedas.get(i);
        if(moneda.comprobarColisiones()){
            moneda.setVisible(false);
            moneda.remove();
            monedas.remove(moneda);
            sonidoMoneda.play();
            contadorMonedas++;}
    }
}
public  void  llegarBandera(){
     float y= jugador.getY()-548;
        musicaFondo.stop();
        sonidoFinal.play(0.9f);
        jugador.setBandera(true);
        puntosExtra=(int)y*1000/450;

}
public void cambiarFuego(){
        jugador.setVivo(false);
        sonidoChampinon.play(0.25f);
    jugador = new JugadorFuego(this,mundo,jugador.getBody().getPosition());
    escenario.addActor(jugador);
}
public void cambiarEstrella(){
        musicaFondo.pause();
        musicaEstrella.play();
    jugador.getFixture().setUserData("jugador_invencible");
    tiempo=0f;
    estrella=true;
}

    public int getPuntosExtra() {
        return puntosExtra;
    }

    public void acabarEstrella(){
        jugador.getFixture().setUserData("jugador");
        tiempo=0f;
        musicaEstrella.stop();
        musicaFondo.play();
}
public void cambiarNormal(){
        sonidoPowerDown.play(0.5f);
        jugador.setVivo(false);
    jugador = new JugadorNormal(this,mundo,new Vector2(jugador.getBody().getPosition().x+0.5f,jugador.getBody().getPosition().y));
    escenario.addActor(jugador);
    cambioNormal=false;
    }
    public void generarSorpresa(Caja box){
        int i=(int)Math.floor(Math.random()*3);
        switch (i){
            case 0:
                box.setSorpresa(Caja.Recompensas.CHAMPINON);
                sonidoPowerUp.play(0.5f);
                break;
            case 1:
                contadorMonedas++;
                sonidoMoneda.play();
                box.setVisible(false);
                break;
            case 2:
                box.setSorpresa(Caja.Recompensas.ESTRELLA);
                sonidoPowerUp.play(0.5f);
                break;
        }
    }
    public class DetectorContactos implements ContactListener {
        private boolean areCollided(Contact contact, Object userA, Object userB) {
            Object userDataA = contact.getFixtureA().getUserData();
            Object userDataB = contact.getFixtureB().getUserData();
            if (userDataA == null || userDataB == null) {
                return false;
            }
            return (userDataA.equals(userA) && userDataB.equals(userB)) ||
                    (userDataA.equals(userB) && userDataB.equals(userA));
        }
        @Override
        public void beginContact(Contact contact) {
            if (areCollided(contact, "jugador", "floor") && jugador.isBandera())
                nivelCompletado=true;
            for(Villano villano: villanos){
                if(areCollided(contact, "jugador_invencible", villano.getId()) || areCollided(contact, "jugador_invencible", villano.getIdsup())){
                    villano.setVivo(false);
                  enemigosAsesinados++;}
                for(Fireball fireball:jugador.getFireballs()){
                if(areCollided(contact,fireball.getId(),villano.getId())) {
                    villano.setVivo(false);
                    fireball.setVisible(false);
                    enemigosAsesinados++;
                }}
                if(areCollided(contact,"jugador",villano.getIdsup())){
                    if(!villano.isCaparazon()){
                        villano.setCaparazon(true);
                        villano.setVivo(false);
                        enemigosAsesinados++;
                    }
                   }
                else if(areCollided(contact,"jugador",villano.getId())&&!villano.isCaparazon()&& !jugador.isSaltando()){
                    jugador.setVivo(false);
                    if(jugador instanceof JugadorNormal)
                       finalJuego=true;
                    else
                        cambioNormal=true;
                    }
                else if(areCollided(contact,"floor",villano.getId())){
                    villano.setSaltando(false);
                }
            }
            if (areCollided(contact, "jugador", "floor")|| areCollided(contact, "jugador_invencible", "floor"))
                jugador.setSaltando(false);
            for(Caja caja :cajas){
            if (areCollided(contact, "jugador", caja.getId())&&caja.getSorpresa()==Caja.Recompensas.SIN_ABRIR){
                generarSorpresa(caja);
                }}
        }

        @Override
        public void endContact(Contact contact){
            if (areCollided(contact, "jugador", "floor")|| areCollided(contact, "jugador_invencible", "floor")) {
                jugador.setSaltando(true);
            }
            for(Villano villano: villanos){
                if(areCollided(contact,"floor",villano.getId())){
                    villano.setSaltando(true);}
    }
        }

        @Override public void preSolve(Contact contact, Manifold oldManifold) { }
        @Override public void postSolve(Contact contact, ContactImpulse impulse) { }
    }
}