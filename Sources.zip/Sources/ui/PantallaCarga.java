package proyecto.juego.ui;

import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class PantallaCarga extends Pantalla {
    private SpriteBatch batch;
    private BitmapFont bm;
    public PantallaCarga(Juego game){
        super(game);
        batch =new SpriteBatch();
        bm= new BitmapFont(new FileHandle("skins/comic/raw/font-title-export.fnt"));}
    @Override
    public void dispose() {
        super.dispose();
    }

    @Override
    public void hide() {
        this.dispose();
    }

    @Override
    public void render(float delta) {
        super.render(delta);
        batch.begin();
        int porcentaje=(int)(game.getAdministrador().getProgress()*100);
        bm.draw(batch,"CARGANDO "+ porcentaje + " %" ,200,300);
        batch.end();
        if (game.getAdministrador().update()) {
            game.setScreen(new PantallaInicio(game));
        }
    }
}
