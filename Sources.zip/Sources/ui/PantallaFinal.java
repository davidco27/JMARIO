package proyecto.juego.ui;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import proyecto.juego.io.IOElementos;

public class PantallaFinal extends Pantalla {
    private Stage escenario;
    private SpriteBatch batch;
    private boolean nuevoRecord;
    private TextButton btnMenu;
    private Label contadorMonedas,contadorAsesinatos,puntuacion,record;
    private BitmapFont bmCompletado,bmHighScore;
    public PantallaFinal(Juego game,PantallaJuego partida){
        super(game);
        escenario =new Stage(new ScreenViewport());
        Skin skin = new Skin(new FileHandle("skins/craftacular/skin/craftacular-ui.json"));
        Skin skin2 = new Skin(new FileHandle("skins/freezing/skin/freezing-ui.json"));
        batch = new SpriteBatch();
        btnMenu = new TextButton("Menu", skin2);
        bmCompletado= new BitmapFont(new FileHandle("skins/craftacular/raw/font-title-export.fnt"));
        bmCompletado.getData().setScale(0.5f,1);
        bmHighScore= new BitmapFont(new FileHandle("skins/star-soldier/raw/font-export.fnt"));
        bmHighScore.getData().setScale(1.5f,1.5f);
        int monedas =partida.getContadorMonedas();
        int asesinatos =partida.getEnemigosAsesinados();
        int puntos=monedas*50+asesinatos*100+partida.getPuntosExtra();
        int puntosMax= IOElementos.leerRecord(partida.getLevel());
        contadorMonedas = new Label(monedas + " COINS",skin);
        contadorMonedas.setPosition(200,280);
        contadorAsesinatos = new Label(asesinatos + " ENEMIES KILLED ",skin);
        contadorAsesinatos.setPosition(200,240);
        puntuacion = new Label( "SCORE  " + puntos,skin);
        puntuacion.setPosition(200,200);
        if(puntos<=puntosMax)
            record = new Label( "HIGHSCORE  " + puntosMax,skin);
        else {
            record = new Label("HIGHSCORE  " + puntos, skin);
            IOElementos.escribirRecord(partida.getLevel(),puntos);
            nuevoRecord=true;
        }
        record.setPosition(200,160);
        escenario.addActor(contadorMonedas);
        escenario.addActor(contadorAsesinatos);
        escenario.addActor(puntuacion);
        escenario.addActor(record);
        escenario.addActor(btnMenu);
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(escenario);
        btnMenu.setPosition(270, 70);
        btnMenu.addListener(new ClickListener(){
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new PantallaInicio(game));
            };
        });}

    @Override
    public void render(float delta) {
        super.render(delta);
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        batch.begin();
        bmCompletado.draw(batch,"LEVEL CLEARED",140,450);
        if(nuevoRecord)
        bmHighScore.draw(batch,"NEW HIGHSCORE",170,350);
        batch.end();
        escenario.act();
        escenario.draw();
    }
    @Override
    public void dispose() {
        escenario.clear();
        escenario.dispose();
    }

    @Override
    public void hide() {
        this.dispose();
    }
}

