package proyecto.juego.ui;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import proyecto.juego.io.IOElementos;

public class PantallaGameOver extends Pantalla {
    private Stage escenario;
    private Image fondo;
    private TextButton btnRetry;
    private TextButton btnMenu;
    private Label contadorMonedas,contadorAsesinatos,puntuacion,record;
    private BitmapFont bmHighScore;
    private  boolean nuevoRecord;
    private PantallaJuego partida;
    private SpriteBatch batch;
    private Sound sonidoMuerte;
    public PantallaGameOver(Juego game,PantallaJuego partida){
        super(game);
        this.partida =partida;
        batch=new SpriteBatch();
        escenario =new Stage(new ScreenViewport());
        Skin skin = new Skin(new FileHandle("skins/craftacular/skin/craftacular-ui.json"));
        Skin skin2 = new Skin(new FileHandle("skins/freezing/skin/freezing-ui.json"));
        btnRetry = new TextButton("Retry", skin2);
        btnMenu = new TextButton("Menu", skin2);
        sonidoMuerte = Juego.getAdministrador().get("audio/muerte.mp3");
        Texture fondoTextura = Juego.getAdministrador().get("imagenes/gameover.png");
        bmHighScore= new BitmapFont(new FileHandle("skins/star-soldier/raw/font-export.fnt"));
        bmHighScore.getData().setScale(1.5f,1.5f);
        fondo =new Image(fondoTextura);
        int monedas =partida.getContadorMonedas();
        int asesinatos =partida.getEnemigosAsesinados();
        int puntos=monedas*50+asesinatos*100;
        int puntosMax= IOElementos.leerRecord(partida.getLevel());
        contadorMonedas = new Label(monedas + " COINS",skin);
        contadorMonedas.setPosition(200,280);
        contadorAsesinatos = new Label(asesinatos + " ENEMIES KILLED ",skin);
        contadorAsesinatos.setPosition(200,240);
        puntuacion = new Label( "SCORE  " + puntos,skin);
        puntuacion.setPosition(200,200);
        escenario.addActor(fondo);
        if(puntos<=puntosMax)
        record = new Label( "HIGHSCORE  " + puntosMax,skin);
        else {
            record = new Label("HIGHSCORE  " + puntos, skin);
            IOElementos.escribirRecord(partida.getLevel(),puntos);
            nuevoRecord=true;
        }
        record.setPosition(200,160);
        fondo.setSize(Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
        fondo.setPosition(fondo.getX(),fondo.getY()+150);
        escenario.addActor(contadorMonedas);
        escenario.addActor(contadorAsesinatos);
        escenario.addActor(puntuacion);
        escenario.addActor(record);
        escenario.addActor(btnMenu);
        escenario.addActor(btnRetry);
        sonidoMuerte.play();
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(escenario);
        btnRetry.setPosition(150, 70);
        btnRetry.addListener(new ClickListener(){
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new PantallaJuego(game,partida.getLevel()));
                sonidoMuerte.stop();
            };
        });
        btnMenu.setPosition(350, 70);
        btnMenu.addListener(new ClickListener(){
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new PantallaInicio(game));
                sonidoMuerte.stop();
            };
        });}

    @Override
    public void render(float delta) {
        super.render(delta);
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        escenario.act();
        escenario.draw();
        if(nuevoRecord){
        batch.begin();
        bmHighScore.draw(batch,"NEW HIGHSCORE",170,350);
        batch.end();}
    }
    @Override
    public void dispose() {
        escenario.clear();
        escenario.dispose();
    }

    @Override
    public void hide() {
        this.dispose();
    }
}

