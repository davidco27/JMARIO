package proyecto.juego.io;
import com.badlogic.gdx.physics.box2d.World;
import proyecto.juego.dominio.*;
import proyecto.juego.ui.PantallaJuego;

import java.io.*;
import java.util.ArrayList;

public class IOElementos {
    public static int leerRecord(int level){
        BufferedReader br;
        FileReader fr;
        int record=0;
        try
        {    fr=new FileReader("archivosPosiciones/nivel"+level+"/record.csv");
            br = new BufferedReader(fr);
           record =Integer.parseInt(br.readLine());
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
        return record;
    }
    public static void escribirRecord(int level,int puntos){
        PrintWriter pr;
        FileWriter fw;
        try
        {    fw=new FileWriter("archivosPosiciones/nivel"+level+"/record.csv");
            pr = new PrintWriter(fw);
            pr.println(puntos);
            try {
                pr.close();
                fw.close();
            }
            catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
    }
    public static ArrayList<Villano> leerEnemigos(PantallaJuego pantalla,World mundo,int level){
        ArrayList<Villano> enemigos= new ArrayList<>();
        FileReader fr;
        float x,y;
        int i=1;
        BufferedReader br;
        try
        {    fr=new FileReader("archivosPosiciones/nivel"+level+"/goombas.csv");
            br = new BufferedReader(fr);
            String linea;
            while((linea =br.readLine())!=null){
                String[] atributos=linea.split(",");
                x=Float.parseFloat(atributos[0]);
                y=Float.parseFloat(atributos[1]);
                enemigos.add(new Goomba(pantalla,mundo,x,y,"v"+i));
                i++;}

        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
        try
        {    fr=new FileReader("archivosPosiciones/nivel" + level +"/tortugas.csv");
            br = new BufferedReader(fr);
            String linea;
            while((linea =br.readLine())!=null){ ;
                String[] atributos=linea.split(",");
                x=Float.parseFloat(atributos[0]);
                y=Float.parseFloat(atributos[1]);
                enemigos.add(new Tortuga(pantalla,mundo,x,y,"t"+i));
                i++;}

        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
      return enemigos;
}

   public static ArrayList<Plataforma> leerPlataformas(World mundo,int level){
        ArrayList<Plataforma> plataformas= new ArrayList<>();
        FileReader fr;
        float x,y;
        float width,height;
        BufferedReader br;
        try
        {    fr=new FileReader("archivosPosiciones/nivel" + level +"/plataformas.csv");
            br = new BufferedReader(fr);
            String linea;
            while((linea =br.readLine())!=null){
                String[] atributos=linea.split(",");
                x=Float.parseFloat(atributos[0]);
                y=Float.parseFloat(atributos[1]);
                height= Float.parseFloat(atributos[2]);
                width=Float.parseFloat(atributos[3]);
                plataformas.add(new Plataforma(mundo,x,y,height,width));}
            br.close();
            fr.close();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
        return plataformas;
    }
    public static ArrayList<Coin> leerMonedas(int level){
        ArrayList<Coin>monedas= new ArrayList<>();
        FileReader fr;
        float x,y;
        int i=1;
        BufferedReader br;
        try
        {
            fr=new FileReader("archivosPosiciones/nivel" + level +"/monedas.csv");
            br = new BufferedReader(fr);
            String linea;
            while((linea =br.readLine())!=null){
                String[] atributos=linea.split(",");
                x=Float.parseFloat(atributos[0]);
                y=Float.parseFloat(atributos[1]);
                monedas.add(new Coin(x,y,"c"+ i));
                i++;}
            br.close();
            fr.close();
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
        return monedas;
    }
    public static ArrayList<Caja> leerCajas(PantallaJuego pantalla,World mundo,int level){
        ArrayList<Caja> cajas= new ArrayList<>();
        FileReader fr;
        float x,y;
        int i=1;
        BufferedReader br;
        try
        {    fr=new FileReader("archivosPosiciones/nivel"+level+"/cajas.csv");
            br = new BufferedReader(fr);
            String linea;
            while((linea =br.readLine())!=null){
                String[] atributos=linea.split(",");
                x=Float.parseFloat(atributos[0]);
                y=Float.parseFloat(atributos[1]);
                cajas.add(new Caja(pantalla,mundo,x,y,"b"+i));
                i++;}

        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
      return cajas;}
}
